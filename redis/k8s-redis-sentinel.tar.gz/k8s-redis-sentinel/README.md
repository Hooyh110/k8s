````
  此yaml为Redis哨兵模式，用于简单部署持久化Redis Sentinel
  使用方法：https://www.cnblogs.com/dukuan/p/9913420.html

````
